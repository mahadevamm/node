module.exports={
    SAVE_USER:"insert into tbl_user set user_name = ?",
}