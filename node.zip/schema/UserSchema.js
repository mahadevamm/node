module.exports={
    SAVE_REQUEST:"insert into tbl_request set ?",
    ALL_REQUEST:"select * from tbl_request where user_id = ?"
}